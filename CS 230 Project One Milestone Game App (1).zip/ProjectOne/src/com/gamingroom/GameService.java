package com.gamingroom;

import java.util.ArrayList;
import java.util.List;

/**
 * A singleton service for the game engine
 * 
 * @author coce@snhu.edu
 */
public class GameService {

	/**
	 * A list of the active games
	 */
	private static List<Game> games = new ArrayList<Game>();

	/*
	 * Holds the next game identifier
	 */
	private static long nextGameId = 1;

	// Singleton instance
	private static GameService instance = null;
	
	// Private constructor prevents external instantiation
	private GameService() {}
	
	// Public accessor for the single instance 
	public static GameService getInstance () {
		if (instance == null) {
			instance = new GameService();
		}
		return instance;
	}
	
	
	/**
	 * Construct a new game instance
	 * 
	 * @param name the unique name of the game
	 * @return the game instance (new or existing)
	 */
	/*
	 * The iterator pattern is used in this class to search through the list of
	 * existing Game objects. Java provides built‑in iterator behavior through
	 * enhanced for‑loops, which allow us to examine each Game in the list.
	 *
	 * Purpose of the iterator pattern in this application:
	 *  - When a user creates a new game, the application must check all existing
	 *    games to ensure the name is not already in use.
	 *  - When retrieving a game by ID or name, we must search through the list
	 *    to find the matching instance.
	 *
	 * By iterating through the list using a for‑each loop, we efficiently check
	 * each Game object without writing a custom iterator. This prevents duplicate
	 * game names and ensures correct retrieval of game instances.
	 */

	public Game addGame(String name) {

		// a local game instance
		Game game = null;
		
		for (Game existing : games) {
			if (existing.getName().equalsIgnoreCase(name)) {
				return existing;  // game already exists
			}
		}
		
		if (game == null) {
			game = new Game(nextGameId++, name);
			games.add(game);
		}

		// return the new/existing game instance to the caller
		return game;
	}

	/**
	 * Returns the game instance at the specified index.
	 * <p>
	 * Scope is package/local for testing purposes.
	 * </p>
	 * @param index index position in the list to return
	 * @return requested game instance
	 */
	Game getGame(int index) {
		return games.get(index);
	}
	
	/**
	 * Returns the game instance with the specified id.
	 * 
	 * @param id unique identifier of game to search for
	 * @return requested game instance
	 */
	public Game getGame(long id) {

		// a local game instance
		Game game = null;

		for (Game existing : games) {
			if (existing.getId() == id) {
				return existing;
			}
		}
		
		return game;
	}

	/**
	 * Returns the game instance with the specified name.
	 * 
	 * @param name unique name of game to search for
	 * @return requested game instance
	 */
	public Game getGame(String name) {

		// a local game instance
		Game game = null;

		for(Game existing : games) {
		if (existing.getName().equalsIgnoreCase(name)) {
			return existing;
		}
	}	
		return game;
}

	/**
	 * Returns the number of games currently active
	 * 
	 * @return the number of games currently active
	 */
	public int getGameCount() {
		return games.size();
	}
}

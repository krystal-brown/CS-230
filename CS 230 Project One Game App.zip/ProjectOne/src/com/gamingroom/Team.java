package com.gamingroom;

import java.util.ArrayList;
import java.util.List;


/**
 * Team extends Entity and holds players
 * Keeping it simple and clean
 */
public class Team extends Entity {
	
	// list of players on this team
	private List<Player> players = new ArrayList<>();
	
	// public constructor so we can actually make teams
	public Team(long id, String name) { 
		super(id, name);
	}
	
	public List<Player> getPlayers() {
        return players;
    }

    public void addPlayer(Player player) {
        players.add(player);
    }

    @Override
    public String toString() {
        return "Team [id=" + id + ", name=" + name + "]";
    }
    
}
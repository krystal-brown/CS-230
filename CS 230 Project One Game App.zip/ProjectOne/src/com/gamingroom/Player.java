package com.gamingroom;

/**
 * Player extends Entity so it uses the shared id and name.
 */
public class Player extends Entity {

    // Constructor passes id and name to Entity
    public Player(long id, String name) {
        super(id, name);
    }

    @Override
    public String toString() {
        return "Player [id=" + id + ", name=" + name + "]";
    }
}

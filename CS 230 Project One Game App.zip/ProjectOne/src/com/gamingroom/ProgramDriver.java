package com.gamingroom;

/**
 * Just testing everything to make sure it works.
 * Keeping it simple and easy to follow.
 */
public class ProgramDriver {

    public static void main(String[] args) {

        // grab the one and only GameService
        GameService service = GameService.getInstance();

        System.out.println("\nTesting game creation...");
        Game game1 = service.addGame("Game #1");
        System.out.println(game1);

        Game game2 = service.addGame("Game #2");
        System.out.println(game2);

        System.out.println("\nTesting team creation...");
        Team teamA = service.addTeam(game1, "Team A");
        System.out.println(teamA);

        System.out.println("\nTesting player creation...");
        Player player1 = service.addPlayer(teamA, "Player One");
        System.out.println(player1);

        System.out.println("\nTesting singleton...");
        SingletonTester tester = new SingletonTester();
        tester.testSingleton();
    }
}


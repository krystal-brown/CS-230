package com.gamingroom;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/**
 * Game extends Entity so it uses the shared id and name.
 * A game can have multiple teams, so we keep a list here.
 */

public class Game extends Entity { 

	// list of teams that belong on this game
	private List<Team> teams = new ArrayList<>();
	
	//constructor passes id and name up to Entity
	public Game(long id, String name) {
		super(id, name);
	}
	
	// returns all teams in this game
	public List<Team> getTeams() {
		return teams;
	}
	
	// adds a teams to this game
	public void addTeam(Team team) {
		teams.add(team);
	}
	
	@Override
	public String toString() {
		return "Game [id=" + id + ", name=" + name + "]";
	}
}
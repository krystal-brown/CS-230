package com.gamingroom;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/**
 * GameService is a singleton. Only one of these exists.
 * This class handles creating games, teams, and players.
 */

public class GameService {

	// the one and only instance
	public static GameService instance = null;
	
	// list of all games
	private List<Game> games = new ArrayList<>();
	
	//id counters
	private static long nextGameId = 1;
	private static long nextTeamId = 1;
	private static long nextPlayerId = 1;

	// private so nobody can make another one
	private GameService() {}
	
	// returns the single instance
	public static GameService getInstance() {
		if (instance == null) {
			instance = new GameService();
		}
		return instance;
	}
	// --- Game Methods ---
	public Game addGame(String name) {
		Iterator<Game> iterator = games.iterator();
		while (iterator.hasNext()) {
			Game current = iterator.next();
			if (current.getName().equalsIgnoreCase(name)) {
				return current; // already exists
			}
		}
		Game newGame = new Game(nextGameId++, name);
		games.add(newGame);
		return newGame;
	}
	public Game getGame(int index) {
		return games.get(index);
	}
	
	public Game getGame(long id) {
		
		Iterator<Game> iterator = games.iterator();
        while (iterator.hasNext()) {
            Game current = iterator.next();
            if (current.getId() == id) {
                return current;
            }
        }
        return null;
    }

    public Game getGame(String name) {
        Iterator<Game> iterator = games.iterator();
        while (iterator.hasNext()) {
            Game current = iterator.next();
            if (current.getName().equalsIgnoreCase(name)) {
                return current;
            }
        }
        return null;
    }

    public int getGameCount() {
        return games.size();
    }


    // --- TEAM METHODS ---
    public Team addTeam(Game game, String teamName) {

        Iterator<Team> iterator = game.getTeams().iterator();
        while (iterator.hasNext()) {
            Team current = iterator.next();
            if (current.getName().equalsIgnoreCase(teamName)) {
                return current; // already exists
            }
        }

        Team newTeam = new Team(nextTeamId++, teamName);
        game.addTeam(newTeam);
        return newTeam;
    }


    // --- PLAYER METHODS ---
    public Player addPlayer(Team team, String playerName) {

        Iterator<Player> iterator = team.getPlayers().iterator();
        while (iterator.hasNext()) {
            Player current = iterator.next();
            if (current.getName().equalsIgnoreCase(playerName)) {
                return current; // already exists
            }
        }

        Player newPlayer = new Player(nextPlayerId++, playerName);
        team.addPlayer(newPlayer);
        return newPlayer;
    }
	
	
}
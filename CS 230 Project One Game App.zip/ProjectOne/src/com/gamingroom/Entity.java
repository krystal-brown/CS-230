package com.gamingroom;

/**
 * Simple base class that just holds id and name
 * All other classes use this so we don't repeat code
 */
public abstract class Entity {
	
	protected long id;
	protected String name;
	
	public Entity(long id, String name) {
		this.id = id;
		this.name = name;
	}

	public long getId() {
		return id;
	}
	public String getName() {
		return name;
	}
}
